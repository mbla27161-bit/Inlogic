# InLogic — корпоративный сайт

Статический сайт экспедиторской компании ООО «ИнЛоджик».

## Структура

```
inlogic-site/
├── index.html                 # Главная
├── pages/
│   ├── about.html             # О компании + лицензии
│   ├── career.html            # Карьера + вакансии
│   ├── contacts.html          # Контакты + форма
│   └── courses.html           # Курсы логистики
├── assets/
│   ├── styles/styles.css      # Единый stylesheet
│   ├── scripts/main.js        # UI: header, menu, counters, forms, to-top
│   ├── icons/
│   │   ├── logo.svg           # Полный логотип (reference)
│   │   └── logo-mark.svg      # Только глобус (currentColor)
│   └── images/                # Растровые ассеты (при необходимости)
└── components/                # Заготовки под будущие partials / шаблоны
```

## Пути

- С корня (`index.html`): `assets/...`, `pages/...`
- Из `pages/`: `../assets/...`, `../index.html`, соседние страницы без префикса

## Логотип

SVG-марка глобуса с двумя геометками + текстовые «InLogic» и «Логистика без границ».
Цвет через `currentColor` (в шапке — зелёный signal на тёмном фоне).

## Что готово к расширению

- Тёмная тема: CSS-переменные в `:root`
- Формы: `.quote-form` + JS-обработчик (пока mock submit)
- Карта / Google Sheets / документы — отдельные секции без ломки вёрстки
- Новые страницы — копировать шаблон header/footer из `pages/`

## Локальный просмотр

```bash
cd inlogic-site && python3 -m http.server 8080
```
